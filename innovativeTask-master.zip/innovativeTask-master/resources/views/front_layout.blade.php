@include('front_layout.header')

@yield('content')

@include('front_layout.footer')

