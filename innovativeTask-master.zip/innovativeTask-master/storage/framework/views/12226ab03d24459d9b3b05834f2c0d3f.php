
<?php if( Session::get('success')  != null): ?>
    <script>
        toastr.success("<?php echo e(Session::get('success')); ?>");
    </script>
<?php endif; ?>

<?php if( Session::get('error')  != null): ?>
    <script>
        toastr.error("<?php echo e(Session::get('error')); ?>");
    </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\innovativeTask-master\innovativeTask-master\resources\views/notifications/notify.blade.php ENDPATH**/ ?>